export const DEF = 'https://upload.wikimedia.org/wikipedia/commons/2/2c/Default_pfp.svg';
export const BASE = 'http://localhost:4002';